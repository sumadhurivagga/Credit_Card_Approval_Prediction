# 💳 Credit Card Approval Prediction

An end-to-end Machine Learning project that predicts whether a credit card application will be **approved or rejected**, based on applicant details such as income, employment status, credit history, and demographics.

🔗 **Live Demo:** [creditcardapprovalprediction.streamlit.app](https://creditcardapprovalprediction-hrzqcjzayrde7zffub5zxc.streamlit.app/)

---

## 📌 Problem Statement

Banks and financial institutions receive thousands of credit card applications daily. Manually reviewing each application is slow, inconsistent, and prone to human bias. This project builds a Machine Learning model that automates the credit card approval decision, helping institutions make faster, data-driven, and consistent decisions.

## 🎯 Objective

- Analyze applicant and credit history data to identify key factors affecting approval.
- Build and train a classification model to predict approval status.
- Deploy the model as an interactive web app for real-time predictions.

## 🗂️ Dataset

- **Source:** [Add dataset source/link — e.g. Kaggle Credit Card Approval Prediction dataset]
- **Features used:** [e.g. Age, Income, Employment Status, Family Size, Housing Type, Credit History Length, etc.]
- **Target variable:** Approval Status (Approved / Rejected)

## 🛠️ Skills Required / Tech Stack

`Xgboost` · `Machine Learning Algorithms` · `Artificial Intelligence` · `Decision Tree Learning` · `NumPy (Python Package)` · `Python (Programming Language)` · `Scikit-Learn (Python Package)` · `Matplotlib (Python Package)`

| Category | Tools/Libraries |
|---|---|
| Language | Python |
| Data Handling | Pandas, NumPy |
| Visualization | Matplotlib, Seaborn |
| Modeling | Scikit-learn, XGBoost, Decision Trees |
| Deployment | Streamlit, Streamlit Cloud |
| Version Control | Git & GitHub |

## 👥 Team

| Name | Role |
|---|---|
| Pamireddy Pradeep Reddy | Team Lead |
| Mamidikayala Deepika | Member |
| Sailekha Reddypalli | Member |
| Shaik Mohammed Saqib Basha | Member |
| Vagga Sumadhuri | Member |

## 🔄 Project Workflow

1. **Brainstorming & Ideation** – Problem understanding and idea prioritization
2. **Data Collection & Preprocessing** – Cleaning, handling missing values, encoding
3. **Exploratory Data Analysis (EDA)** – Understanding feature relationships and trends
4. **Feature Engineering** – Selecting and transforming the most relevant features
5. **Model Building** – Training classification models (e.g. Logistic Regression, Random Forest, XGBoost)
6. **Model Evaluation** – Comparing models using accuracy, precision, recall, F1-score
7. **Deployment** – Deploying the final model using Streamlit Cloud
8. **Documentation** – Complete project documentation and presentation

> 📁 Detailed phase-wise documentation is available in the project folders above (see repository structure).

## 📊 Model Performance

| Metric | Score |
|---|---|
| Accuracy | [Add score] |
| Precision | [Add score] |
| Recall | [Add score] |
| F1-Score | [Add score] |

## 🚀 How to Run Locally

```bash
# Clone the repository
git clone https://github.com/<your-username>/<your-repo-name>.git
cd <your-repo-name>

# Install dependencies
pip install -r requirements.txt

# Run the Streamlit app
streamlit run app.py
```

## 📁 Repository Structure

```
├── 1. Brainstorming & Ideation/
├── 2. Data Collection & Preprocessing/
├── 3. Exploratory Data Analysis/
├── 4. Feature Engineering/
├── 5. Model Building/
├── 6. Model Evaluation/
├── 7. Deployment/
├── 8. Documentation/
├── app.py
├── model.pkl
├── requirements.txt
└── README.md
```

## 🌐 Live Application

👉 Try it here: **[Credit Card Approval Prediction App](https://creditcardapprovalprediction-hrzqcjzayrde7zffub5zxc.streamlit.app/)**


